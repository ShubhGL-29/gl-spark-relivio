package com.relivio.incident;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IncidentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
