package com.relivio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResourceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
